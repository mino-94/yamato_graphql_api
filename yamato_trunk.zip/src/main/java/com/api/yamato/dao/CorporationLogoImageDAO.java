package com.api.yamato.dao;

import com.api.yamato.domain.CorporationLogoImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorporationLogoImageDAO extends JpaRepository<CorporationLogoImage, Object> {

    /**
     * 기업 로고이미지 조회
     **/
    CorporationLogoImage findByBizno(String bizno);

}