package com.api.yamato.action;

import com.api.yamato.util.Valid;
import com.fasterxml.jackson.databind.ObjectMapper;
import graphql.GraphQLError;
import graphql.GraphQLException;
import graphql.GraphqlErrorBuilder;
import graphql.GraphqlErrorHelper;
import graphql.language.SourceLocation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RestControllerAdvice
public class ExceptionAction implements ErrorController {


    @RequestMapping(value = "/error", produces = "application/json")
    private Map errorHandler(HttpServletRequest request, HttpServletResponse response) {
        Map result = new HashMap<>();
        String uri = (String) request.getAttribute(RequestDispatcher.ERROR_REQUEST_URI);

        if (request.getRequestURL().equals(uri)) {
            Valid.getErrResn(HttpStatus.NOT_FOUND, result, uri);
        } else {
            try {
                result = (Map) request.getAttribute(RequestDispatcher.ERROR_MESSAGE);
            } catch (Exception e) {
                Valid.getErrResn(null, result, e.getMessage());
            }
        }
        result = Valid.createTemplate(result);

        log.error(result.toString());

        return result;
    }

    @ExceptionHandler(value = GraphQLException.class)
    private Map exceptionHandler(GraphQLException e) {
        Map result = new HashMap<>();
        String msg = e.getMessage();

        if (msg.startsWith("{\"") && msg.endsWith("}")) {
            try {
                result = new ObjectMapper().readValue(msg, Map.class);
            } catch (Exception ex) {
                Valid.getErrResn(null, result, ex.getMessage());
                result = Valid.createTemplate(result);
            }
        } else {
            String locations = msg.substring(msg.lastIndexOf(" at line") + 4);
            String line = locations.substring(locations.indexOf("line ") + 5, locations.indexOf(" column"));
            String column = locations.substring(locations.indexOf("column ") + 7);

            SourceLocation location = new SourceLocation(Integer.parseInt(line), Integer.parseInt(column));
            Map extention = new HashMap<>();
            extention.put("classification", msg.substring(0, msg.indexOf(" :")).replace(" ", ""));

            GraphQLError error = GraphqlErrorBuilder.newError().message(msg).location(location).extensions(extention).build();
            result = Valid.createTemplate(GraphqlErrorHelper.toSpecification(error));
        }
        log.error(result.toString());

        return result;
    }

}
