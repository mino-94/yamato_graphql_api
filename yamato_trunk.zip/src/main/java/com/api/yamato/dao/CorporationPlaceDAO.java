package com.api.yamato.dao;

import com.api.yamato.domain.CorporationPlace;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorporationPlaceDAO extends JpaRepository<CorporationPlace, Object> {

    /**
     * 기업 사업장 조회
     **/
    CorporationPlace findByKiscodeAndBizloSeq(String kiscode, int bizloSeq);

    CorporationPlace findFirstByKiscodeAndBizlodivcdOrderByBizloSeq(String kiscode, String divcd);

}