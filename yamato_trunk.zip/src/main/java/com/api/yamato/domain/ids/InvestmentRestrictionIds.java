package com.api.yamato.domain.ids;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import java.io.Serializable;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
public class InvestmentRestrictionIds implements Serializable {

    String kyelcd;

    String yyyy;

}
