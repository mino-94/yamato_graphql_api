package com.api.yamato.dao;

import com.api.yamato.domain.GroupOverview;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroupOverviewDAO extends JpaRepository<GroupOverview, Object> {

    /**
     * 그룹 개요 조회
     **/
    GroupOverview findByKyelcd(String gicd);

}