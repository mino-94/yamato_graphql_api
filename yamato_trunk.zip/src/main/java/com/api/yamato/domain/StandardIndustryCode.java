package com.api.yamato.domain;

import com.api.yamato.domain.ids.StandardIndustryCodeIds;
import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_em..s_em005")
@IdClass(StandardIndustryCodeIds.class)
public class StandardIndustryCode {

    @Id
    @GraphQLNonNull
    String idscdcg;

    @Id
    String idscdid;

    @Id
    @Column(name = "upchecd")
    String kiscode;

    @Column(name = "idscd_mng_rnk")
    Integer idscdMngRnk;

}
