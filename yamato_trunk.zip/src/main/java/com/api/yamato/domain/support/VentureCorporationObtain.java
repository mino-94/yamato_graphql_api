package com.api.yamato.domain.support;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_a1..aa31")
public class VentureCorporationObtain {

    @Id
    @Column(name = "business_no")
    String bizno;

    @Column(name = "upchecd")
    String kiscode;

    String sdate;

    String edate;

    String fdate;

}
