package com.api.yamato.conf;

import org.hibernate.dialect.SybaseDialect;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.type.Type;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class FunctionConfig extends SybaseDialect {


    public FunctionConfig() {
        super();

        Map functions = new HashMap<>();
        setFunctions(functions);

        Iterator<String> iterator = functions.keySet().iterator();
        String function = "";

        while (iterator.hasNext()) {
            function = iterator.next();

            registerFunction(function, new StandardSQLFunction(function, (Type) functions.get(function)));
        }
    }

    private void setFunctions(Map functions) {
        functions.put("kis.dbo.fnc003_slct_bdt_by_skvl", StandardBasicTypes.STRING);
        functions.put("kis.dbo.fnc001_slct_svc_kor_cdvl", StandardBasicTypes.STRING);
        functions.put("kis.dbo.fnc002_slct_svc_eng_cdvl", StandardBasicTypes.STRING);
    }

}
