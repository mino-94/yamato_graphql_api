package com.api.yamato.svc;

import com.api.yamato.dao.*;
import com.api.yamato.domain.*;
import com.api.yamato.util.Valid;
import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class CorporationService {

    @Autowired
    private CorporationOverviewDAO corporationOverviewDAO;

    @Autowired
    private GroupOverviewDAO groupOverviewDAO;

    @Autowired
    private CorporationBankCodeDAO corporationBankCodeDAO;

    @Autowired
    private CorporationStockCodeDAO corporationStockCodeDAO;

    @Autowired
    private CorporationNoStatusCodeDAO corporationNoStatusCodeDAO;

    @Autowired
    private CorporationPlaceDAO corporationPlaceDAO;

    @Autowired
    private CorporationAddressDAO corporationAddressDAO;

    @Autowired
    private CorporationHupeCodeDAO corporationHupeCodeDAO;

    @Autowired
    private CorporationDtlContDAO corporationDtlContDAO;

    @Autowired
    private CorporationOwnerDAO corporationOwnerDAO;

    @Autowired
    private CorporationLogoImageDAO corporationLogoImageDAO;

    @Autowired
    private SpecialCorporationDAO specialCorporationDAO;


    /**
     * 기업 개요 조회
     **/
    public CorporationOverview getCorporationOverview(@GraphQLNonNull String allsvcpdtcd, @GraphQLNonNull String kiscode) {
        CorporationOverview corpOverview = corporationOverviewDAO.findCorporationOverview(kiscode);

        if (corpOverview != null) {
            corpOverview.setCrpno_rsdrgsbdtsexvl(corporationOverviewDAO.findRsdrgsbdtsexvl(corpOverview.getCrpno()));
            corpOverview.setRepr_rsdrgsbdtsexvl(corporationOverviewDAO.findRsdrgsbdtsexvl(corpOverview.getRepr_regno()));
            corpOverview.setFa_bse_date(corporationOverviewDAO.findKgaapFinance(corpOverview.getKiscode()));
            corpOverview.setBtpnm(corporationOverviewDAO.findSvcKorCdvl(allsvcpdtcd, "eprdatastsdivcd", corpOverview.getEprdatastsdivcd()));
            corpOverview.setEng_btpnm(corporationOverviewDAO.findSvcEngCdvl(allsvcpdtcd, "eprdatastsdivcd", corpOverview.getEprdatastsdivcd()));
            corpOverview.setScl(corporationOverviewDAO.findSvcKorCdvl(allsvcpdtcd, "scaledivcd", corpOverview.getScaledivcd()));
            corpOverview.setEng_scl(corporationOverviewDAO.findSvcEngCdvl(allsvcpdtcd, "scaledivcd", corpOverview.getScaledivcd()));
            corpOverview.setChulja(corporationOverviewDAO.findInvestmentRestriction(corpOverview.getGicd()));

            if (StringUtils.isNotEmpty(corpOverview.getUpt_dtm())) {
                corpOverview.setUpt_date(corpOverview.getUpt_dtm().substring(0, 10).replace("-", ""));
            }
        }
        return corpOverview;
    }

    /**
     * 그룹 개요 조회
     **/
    public GroupOverview getGroupOverview(@GraphQLNonNull String gicd) {
        return groupOverviewDAO.findByKyelcd(gicd);
    }

    /**
     * 기업 은행코드 조회
     **/
    public CorporationBankCode getCorporationBankCode(@GraphQLNonNull String bankcd) {
        return corporationBankCodeDAO.findByBankcd(bankcd);
    }

    /**
     * 기업 주식코드 조회
     **/
    public CorporationStockCode getCorporationStockCode(@GraphQLNonNull String kiscode) {
        return corporationStockCodeDAO.findByKiscodeAndStkcdEndingWith(kiscode, "0");
    }

    /**
     * 기업 법인등록번호 등기상태 조회
     **/
    public CorporationNoStatusCode getCorporationNoStatusCode(@GraphQLNonNull String crpno) {
        return corporationNoStatusCodeDAO.findByCrpno(crpno);
    }

    /**
     * 기업 사업장 조회
     **/
    public CorporationPlace getCorporationPlace(@GraphQLNonNull String kiscode, int bizloSeq) {
        CorporationPlace corpPlace = corporationPlaceDAO.findByKiscodeAndBizloSeq(kiscode, bizloSeq);
        integratePlaceAddress(corpPlace, kiscode);

        return corpPlace;
    }

    /**
     * 기업 주소 조회
     **/
    public CorporationAddress getCorporationAddress(@GraphQLNonNull String kiscode, int bizloSeq) {
        CorporationAddress corpAddr = corporationAddressDAO.findByKiscodeAndBizloSeq(kiscode, bizloSeq);
        integratePlaceAddress(corpAddr, kiscode);

        return corpAddr;
    }

    /**
     * 기업 휴폐업구분 조회
     **/
    public CorporationHupeCode getCorporationHupeCode(@GraphQLNonNull String bizno) {
        CorporationHupeCode corpHupeCode = corporationHupeCodeDAO.findByBizno(bizno);
//        Charset charset = Charset.forName("UTF-8");
//        Resources.setCharset(charset);
//        Document codeTable = xmlCode.getDoc(DefaultAction.CODE_TABLE);
//        Element node = (Element) XPath.selectSingleNode(codeTable, "CodeTable/ServiceUnit[@code='LA0111']/Items");
//
//        List lCode = node.getChildren("Item");
//        String sContents = "";
//        Element code;
//
//        for (int i = 0; i < lCode.size(); i++) {
//            code = (Element) lCode.get(i);
//            if (sCode.equals(code.getAttributeValue("code"))) {
//                sContents = code.getAttributeValue("name");
//            }
//        }
        //XML Parsing 미구현으로 하드코딩
        Map gbn = new HashMap<>();
        gbn.put("00", "미등록");
        gbn.put("01", "간이과세자");
        gbn.put("02", "면세사업자");
        gbn.put("03", "일반과세자");
        gbn.put("04", "비영리법인");
        gbn.put("05", "폐업자");
        gbn.put("06", "휴업자");
        gbn.put("99", "기타");

        if (gbn.get(corpHupeCode.getHupegbn()) != null) {
            corpHupeCode.setHupegbn((String) gbn.get(corpHupeCode.getHupegbn()));
        } else {
            corpHupeCode.setHupegbn("");
        }
        return corpHupeCode;
    }

    /**
     * 기업 특이사항 조회
     **/
    public CorporationDtlCont getCorporationDtlCont(@GraphQLNonNull String kiscode) {
        List<CorporationDtlCont> corpDtlConts = corporationDtlContDAO.findByKiscodeOrderBySeq(kiscode);
        CorporationDtlCont corpDtlCont = new CorporationDtlCont();
        StringBuilder sDtlCont = new StringBuilder();

        for (int i = 0; i < corpDtlConts.size(); i ++) {
            sDtlCont.append(corpDtlConts.get(i).getDtlcont());

            if (i != (corpDtlConts.size() - 1)) {
                sDtlCont.append(",");
            }
        }
        corpDtlCont.setKiscode(kiscode);
        corpDtlCont.setDtlcont(sDtlCont.toString());

        return corpDtlCont;
    }

    /**
     * 기업 인물코드 조회
     **/
    public CorporationOwner getCorporationOwner(@GraphQLNonNull String kiscode, @GraphQLNonNull String korreprnm) {
        CorporationOwner corpOwner = new CorporationOwner();
        StringBuilder sOwnerCode = new StringBuilder();
        String[] arrOwner = {};
        String sTempOwnerCode = "";

        if (StringUtils.isNotEmpty(korreprnm)) {
            arrOwner = korreprnm.split("/");
        }

        for (int i = 0; i < arrOwner.length; i ++) {
            if (i > 0) {
                sOwnerCode.append("/");
            }
            sTempOwnerCode = corporationOwnerDAO.findPersionOverview(kiscode, arrOwner[i]);

            if (StringUtils.isEmpty(sTempOwnerCode) || "null".equals(sTempOwnerCode)) {
                sTempOwnerCode = "";
            }
            sOwnerCode.append(sTempOwnerCode);
        }
        corpOwner.setKorreprcd(sOwnerCode.toString());

        return corpOwner;
    }

    /**
     * kisreport out link 조회
     **/
    public KisreportOutLink getKisreportOutLink(@GraphQLNonNull String kiscode) {
        KisreportOutLink outLink = new KisreportOutLink();

        if (StringUtils.isNotEmpty(kiscode)) {
            outLink.setKisreporturl("http://old.kisreport.com/embedded/outlink.asp?s=SR04201&upchecd=" + kiscode + "&siteid=DPP");
        } else {
            outLink.setKisreporturl("");
        }
        return outLink;
    }

    /**
     * 기업 로고이미지 조회
     **/
    public CorporationLogoImage getCorporationLogoImage(@GraphQLNonNull String bizno) {
        CorporationLogoImage corpLogoImg = corporationLogoImageDAO.findByBizno(bizno);
        String logo = corpLogoImg.getLogo();

        if (StringUtils.isNotEmpty(logo)) {
            corpLogoImg.setLogo("http://image.kisline.com" + logo);
            corpLogoImg.setLogossl("https://image.kisline.com" + logo);
        } else {
            corpLogoImg.setLogossl("");
        }
        return corpLogoImg;
    }

    /**
     * 특수기업 조회
     **/
    public SpecialCorporation getSpecialCorporation(@GraphQLNonNull String kiscode) {
        SpecialCorporation special = new SpecialCorporation();
        special.setSmanda(specialCorporationDAO.findMergerAndAcquisition(kiscode));
        special.setSlandc(specialCorporationDAO.findCorporationRehabilitation(kiscode));
        special.setSventure(specialCorporationDAO.findVentureCorporationObtain(kiscode));
        special.setSforeign(specialCorporationDAO.findForeignCorporationHistory(kiscode));

        return special;
    }

    private void integratePlaceAddress(Object cls, String kiscode) {
        CorporationPlace tmpPlace = null;
        Field subField = null;
        Object subTmp = null;
        String[] divcds = {"02", "03"};
        String name = "";

        for (String divcd : divcds) {
            tmpPlace = corporationPlaceDAO.findFirstByKiscodeAndBizlodivcdOrderByBizloSeq(kiscode, divcd);

            if (tmpPlace != null) {
                if (cls instanceof CorporationPlace) {
                    subTmp = corporationPlaceDAO.findByKiscodeAndBizloSeq(kiscode, tmpPlace.getBizloSeq());
                } else {
                    subTmp = corporationAddressDAO.findByKiscodeAndBizloSeq(kiscode, tmpPlace.getBizloSeq());
                }

                if (subTmp != null) {
                    try {
                        for (Field field : cls.getClass().getDeclaredFields()) {
                            field.setAccessible(true);
                            name = field.getName();

                            if (name.substring(name.length() - 1).equals(divcd.substring(1))) {
                                subField = subTmp.getClass().getDeclaredField(name.substring(0, name.length() - 1));
                                subField.setAccessible(true);

                                field.set(cls, subField.get(subTmp));
                            }
                        }
                    } catch (Exception e) {
                        log.error(Valid.printStackTrace(e));

                        break;
                    }
                }
            }
        }
    }

}
