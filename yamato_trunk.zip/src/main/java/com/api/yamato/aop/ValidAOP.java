package com.api.yamato.aop;

import com.api.yamato.util.Valid;
import graphql.GraphQLException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.json.JSONObject;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;


@Aspect
@Component
public class ValidAOP {


    @Around("execution(public Object io.leangen.graphql.spqr.spring.web.HttpExecutor.execute(..))")
    private Map validExecuteHandler(ProceedingJoinPoint point) throws Throwable {
        Object obj = point.proceed();

        Map result = new HashMap<>();
        Mono<Object> mono = (Mono<Object>) obj;
        mono.subscribe(data -> result.putAll((Map) data));

        if (result.containsKey("errors")) {
            throw new GraphQLException(new JSONObject(result).toString());
        }
        return result;
    }

    @Around("execution(public * com.api.yamato.dao..*(..))")
    public Object validServiceHandler(ProceedingJoinPoint point) throws Throwable {
        return Valid.convertResult(point.proceed());
    }

}
