package com.api.yamato.dao;

import com.api.yamato.domain.support.QCorporationRehabilitation;
import com.api.yamato.domain.support.QForeignCorporationHistory;
import com.api.yamato.domain.support.QMergerAndAcquisition;
import com.api.yamato.domain.support.QVentureCorporationObtain;
import com.querydsl.jpa.JPAExpressions;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.text.SimpleDateFormat;
import java.util.Date;

@Repository
public class SpecialCorporationDAO {

    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    private QMergerAndAcquisition qMergerAndAcquisition = QMergerAndAcquisition.mergerAndAcquisition;

    private QCorporationRehabilitation qCorporationRehabilitation = QCorporationRehabilitation.corporationRehabilitation;

    private QVentureCorporationObtain qVentureCorporationObtain = QVentureCorporationObtain.ventureCorporationObtain;

    private QForeignCorporationHistory qForeignCorporationHistory = QForeignCorporationHistory.foreignCorporationHistory;


    /**
     * 특수기업 조회
     **/
    public String findMergerAndAcquisition(String kiscode) {
        return jpaQueryFactory.selectFrom(qMergerAndAcquisition).where(qMergerAndAcquisition.unite_kiscode.eq(kiscode)).fetchFirst() != null ? "M&A 이력" : "";
    }

    public String findCorporationRehabilitation(String kiscode) {
        return jpaQueryFactory.selectFrom(qCorporationRehabilitation).where(qCorporationRehabilitation.kiscode.eq(kiscode)).fetchFirst() != null ? "법정관리 및 화의 이력력" : "";
    }

    public String findVentureCorporationObtain(String kiscode) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        String today = simpleDateFormat.format(new Date());

        return jpaQueryFactory.selectFrom(qVentureCorporationObtain).where(qVentureCorporationObtain.kiscode.eq(kiscode)
                                                                .and(qVentureCorporationObtain.sdate.loe(today)).and(qVentureCorporationObtain.edate.goe(today))
                                                                .and(qVentureCorporationObtain.fdate.eq(JPAExpressions.select(qVentureCorporationObtain.fdate.max())
                                                                        .from(qVentureCorporationObtain)))).fetchFirst() != null ? "벤쳐기업" : "";
    }

    public String findForeignCorporationHistory(String kiscode) {
        return jpaQueryFactory.selectFrom(qForeignCorporationHistory).where(qForeignCorporationHistory.kiscode.eq(kiscode)
                                                                .and(qForeignCorporationHistory.yyyy.eq(JPAExpressions.select(qForeignCorporationHistory.yyyy.max())
                                                                        .from(qForeignCorporationHistory)))).fetchFirst() != null ? "외투기업" : "";
    }

}
