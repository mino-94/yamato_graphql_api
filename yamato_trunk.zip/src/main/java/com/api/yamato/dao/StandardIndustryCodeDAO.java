package com.api.yamato.dao;

import com.api.yamato.domain.StandardIndustryCode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StandardIndustryCodeDAO extends JpaRepository<StandardIndustryCode, Object> {

    /**
     * 표준 산업코드 조회
     **/
    StandardIndustryCode findByKiscodeAndIdscdcgAndIdscdMngRnk(String kiscode, String idscdcg, int ids_mng_rnk);

}
