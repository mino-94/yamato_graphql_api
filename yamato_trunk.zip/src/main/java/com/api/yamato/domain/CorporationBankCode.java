package com.api.yamato.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_a1..ax03")
public class CorporationBankCode {

    @Id
    @GraphQLNonNull
    String bankcd;

    @Column(name = "bank_kor")
    String bnknm;

    @Column(name = "bank_eng")
    String eng_bnknm;

}
