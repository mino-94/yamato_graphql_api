package com.api.yamato.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_a1..s_a1540")
public class CorporationLogoImage {

    @Id
    @GraphQLNonNull
    String bizno;

    @Column(name = "tbnl_img_savurl")
    String logo;

    @Transient
    String logossl;

}
