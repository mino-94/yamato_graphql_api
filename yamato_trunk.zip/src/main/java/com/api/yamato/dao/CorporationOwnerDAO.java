package com.api.yamato.dao;

import com.api.yamato.domain.support.QPersonCorporation;
import com.api.yamato.domain.support.QPersonOverview;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CorporationOwnerDAO {

    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    private QPersonOverview qPersonOverview = QPersonOverview.personOverview;

    private QPersonCorporation qPersonCorporation = QPersonCorporation.personCorporation;


    /**
     * 기업 인물코드 조회
     **/
    public String findPersionOverview(String kiscode, String owner) {
        return jpaQueryFactory.select(qPersonOverview.inmulcd).from(qPersonOverview).innerJoin(qPersonCorporation)
                .on(qPersonOverview.inmulcd.eq(qPersonCorporation.inmulcd))
                .where(qPersonOverview.name_kor.eq(owner).and(qPersonCorporation.kiscode.eq(kiscode))
                        .and(qPersonCorporation.representative.ne("0")).and(qPersonCorporation.gubun.eq("1"))).fetchOne();
    }

}