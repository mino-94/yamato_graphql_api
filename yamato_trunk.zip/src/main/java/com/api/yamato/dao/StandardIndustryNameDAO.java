package com.api.yamato.dao;

import com.api.yamato.domain.StandardIndustryName;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StandardIndustryNameDAO extends JpaRepository<StandardIndustryName, Object> {

    /**
     * 표준 산업이름 조회
     **/
    StandardIndustryName findByIdscdid(String idscdid);

}