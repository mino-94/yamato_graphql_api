package com.api.yamato.domain;

import com.api.yamato.domain.ids.CorporationPlaceIds;
import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.*;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_em..s_em002")
@IdClass(CorporationPlaceIds.class)
public class CorporationPlace {

    @Id
    @Column(name = "upchecd")
    @GraphQLNonNull
    String kiscode;

    String obz_date;

    String sbqc_date;

    String zcd;

    @Transient
    String zcd2;

    @Transient
    String zcd3;

    String zarcd;

    @Transient
    String zarcd2;

    @Transient
    String zarcd3;

    String zipareacdseq;

    @Transient
    String zipareacdseq2;

    @Transient
    String zipareacdseq3;

    String koraddr;

    @Transient
    String koraddr2;

    @Transient
    String koraddr3;

    String engaddr;

    @Transient
    String engaddr2;

    @Transient
    String engaddr3;

    String nolt_koraddr;

    @Transient
    String nolt_koraddr2;

    @Transient
    String nolt_koraddr3;

    String nolt_engaddr;

    @Transient
    String nolt_engaddr2;

    @Transient
    String nolt_engaddr3;

    @Column(name = "btpnm")
    String rbtpnm;

    @Transient
    String rbtpnm2;

    @Transient
    String rbtpnm3;

    String bzdnm;

    @Transient
    String bzdnm2;

    @Transient
    String bzdnm3;

    @Column(name = "faxno")
    String fax;

    @Transient
    String fax2;

    @Transient
    String fax3;

    String tel;

    @Transient
    String tel2;

    @Transient
    String tel3;

    @Column(name = "xxs_poicdtvl")
    String x;

    @Transient
    String x2;

    @Transient
    String x3;

    @Column(name = "yxs_poicdtvl")
    String y;

    @Transient
    String y2;

    @Transient
    String y3;

    String bizlodivcd;

    @Id
    @Column(name = "bizlo_seq")
    Integer bizloSeq;

}
