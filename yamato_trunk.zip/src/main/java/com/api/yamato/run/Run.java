package com.api.yamato.run;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import static com.api.yamato.value.Values.PACKAGE_PATH;

@EnableAspectJAutoProxy
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = PACKAGE_PATH + ".dao")
@EntityScan(basePackages = PACKAGE_PATH + ".domain")
@SpringBootApplication(scanBasePackages = PACKAGE_PATH)
public class Run {


    public static void main(String[] args) {
        SpringApplication.run(Run.class, args);
    }

}

