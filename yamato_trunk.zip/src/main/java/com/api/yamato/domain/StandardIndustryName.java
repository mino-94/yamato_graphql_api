package com.api.yamato.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_a1..s_a1502")
public class StandardIndustryName {

    @Id
    @GraphQLNonNull
    String idscdid;

    String idscd;

    String kor_idscdnm;

    String eng_idscdnm;

}
