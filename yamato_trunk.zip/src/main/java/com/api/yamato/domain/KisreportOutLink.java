package com.api.yamato.domain;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
public class KisreportOutLink {

    String kisreporturl;

}
