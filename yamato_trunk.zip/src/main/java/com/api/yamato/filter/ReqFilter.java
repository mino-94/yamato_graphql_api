package com.api.yamato.filter;

import com.api.yamato.util.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Map;

@Slf4j
@WebFilter("/*")
@Component
public class ReqFilter implements Filter {

    @Value("${yamato.request.body.enable-logging}")
    private boolean enable;


    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        ReadableReqWrapper request = new ReadableReqWrapper((HttpServletRequest) servletRequest);
        String uri = request.getRequestURI();
        boolean except = false;
        Valid.validMethod(request);

        if (CollectionUtils.isEmpty((Map) request.getAttribute(RequestDispatcher.ERROR_MESSAGE))) {
            String body = request.getBody();
            boolean schema = Valid.validRequestSchema(request, body);
            Valid.validOptions(request, body);

            if (CollectionUtils.isEmpty((Map) request.getAttribute(RequestDispatcher.ERROR_MESSAGE))) {
                filterChain.doFilter(request, servletResponse);
                return;
            } else {
                if (((Map) request.getAttribute(RequestDispatcher.ERROR_MESSAGE)).containsKey("chk")) {
                    Valid.validPost(request, body);

                    if (CollectionUtils.isEmpty((Map) request.getAttribute(RequestDispatcher.ERROR_MESSAGE))) {
                        if (!schema && enable) {
                            log.info("Yamato Request Body:\n" + body);
                        }
                        request.setAttribute("body", body);

                        try {
                            filterChain.doFilter(request, servletResponse);
                        } catch (Exception e) {
                            except = true;

                            throw e;
                        } finally {
                            if (schema) {
                                if (except) {
                                    log.error("Yamato Request Defined Schema: Download Fail");
                                } else {
                                    log.info("Yamato Request Defined Schema: Download Success");
                                }
                            }
                        }
                        return;
                    }
                }
            }
        }
        request.setAttribute(RequestDispatcher.ERROR_REQUEST_URI, uri);
        request.getRequestDispatcher("/error").forward(request, servletResponse);
    }

}
