package com.api.yamato.dao;

import com.api.yamato.domain.CorporationStockCode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorporationStockCodeDAO extends JpaRepository<CorporationStockCode, Object> {

    /**
     * 기업 주식코드 조회
     **/
    CorporationStockCode findByKiscodeAndStkcdEndingWith(String kiscode, String like);

}