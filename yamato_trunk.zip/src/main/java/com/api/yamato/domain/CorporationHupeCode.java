package com.api.yamato.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_ba..s_ba560")
public class CorporationHupeCode {

    @Id
    @GraphQLNonNull
    String bizno;

    @Column(name = "nts_sbqcdivcd")
    String hupegbn;

}
