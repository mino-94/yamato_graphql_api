package com.api.yamato.domain.support;

import com.api.yamato.domain.ids.PersonCorporationIds;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_ma..mb02")
@IdClass(PersonCorporationIds.class)
public class PersonCorporation {

    @Id
    String inmulcd;

    @Column(name = "upchecd")
    String kiscode;

    String representative;

    String gubun;

    @Id
    Integer seq;

}
