package com.api.yamato.conf;

import com.p6spy.engine.logging.Category;
import com.p6spy.engine.spy.P6SpyOptions;
import com.p6spy.engine.spy.appender.MessageFormattingStrategy;
import org.apache.commons.lang.StringUtils;
import org.hibernate.engine.jdbc.internal.FormatStyle;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.Locale;

@Configuration
public class P6SpyConfig implements MessageFormattingStrategy {


    @Override
    public String formatMessage(int connectionId, String now, long elapsed, String category, String prepared, String sql, String url) {
        String format = "Elapsed: " + elapsed + "ms\nHibernateFormat(P6Spy p6spy) :";

        if (StringUtils.isNotEmpty(sql) && Category.STATEMENT.getName().equals(category)) {
            FormatStyle formatStyle = null;
            sql = sql.trim().toLowerCase(Locale.ROOT);

            if (sql.startsWith("create") || sql.startsWith("alter") || sql.startsWith("comment")) {
                formatStyle = FormatStyle.DDL;
            } else {
                formatStyle = FormatStyle.BASIC;
            }
            format += formatStyle.getFormatter().format(sql);
        } else {
            format += null;
        }
        return format;
    }

    @PostConstruct
    private void setPrettyLogging() {
        P6SpyOptions.getActiveInstance().setLogMessageFormat(this.getClass().getName());
    }

}
