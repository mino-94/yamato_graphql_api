package com.api.yamato.dao;

import com.api.yamato.domain.CorporationOverview;
import com.api.yamato.domain.QCorporationOverview;
import com.api.yamato.domain.support.QCorporationKgaapFinance;
import com.api.yamato.domain.support.QInvestmentRestriction;
import com.querydsl.core.types.dsl.Expressions;
import com.querydsl.core.types.dsl.StringTemplate;
import com.querydsl.jpa.JPAExpressions;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CorporationOverviewDAO {

    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    private QCorporationOverview qCorporationOverview = QCorporationOverview.corporationOverview;

    private QCorporationKgaapFinance qCorporationKgaapFinance = QCorporationKgaapFinance.corporationKgaapFinance;

    private QInvestmentRestriction qInvestmentRestriction = QInvestmentRestriction.investmentRestriction;


    /**
     * 기업 개요 조회
     **/
    public CorporationOverview findCorporationOverview(String kiscode) {
        return jpaQueryFactory.selectFrom(qCorporationOverview).where(qCorporationOverview.kiscode.eq(kiscode)).fetchOne();
    }

    public String findRsdrgsbdtsexvl(String rsdrgsbdtsexvl) {
        StringTemplate template = Expressions.stringTemplate("kis.dbo.fnc003_slct_bdt_by_skvl({0}, 7, null, null)", rsdrgsbdtsexvl);

        return jpaQueryFactory.select(template.length().when(7).then(template).otherwise(""))
                .from(qCorporationOverview).fetchFirst();
    }

    public String findKgaapFinance(String kiscode) {
        return jpaQueryFactory.select(qCorporationKgaapFinance.stac_date.max()).from(qCorporationKgaapFinance)
                .where(qCorporationKgaapFinance.kiscode.eq(kiscode).and(qCorporationKgaapFinance.stacdivcd.eq("K"))).fetchOne();
    }

    public String findSvcKorCdvl(String allsvcpdtcd, String key, String value) {
        return jpaQueryFactory.select(Expressions.stringTemplate("kis.dbo.fnc001_slct_svc_kor_cdvl({0}, {1}, {2})", allsvcpdtcd, key, value))
                .from(qCorporationOverview).fetchFirst();
    }

    public String findSvcEngCdvl(String allsvcpdtcd, String key, String value) {
        return jpaQueryFactory.select(Expressions.stringTemplate("kis.dbo.fnc002_slct_svc_eng_cdvl({0}, {1}, {2})", allsvcpdtcd, key, value))
                .from(qCorporationOverview).fetchFirst();
    }

    public String findInvestmentRestriction(String gicd) {
        return jpaQueryFactory.select(qInvestmentRestriction.chulja).from(qInvestmentRestriction).where(qInvestmentRestriction.kyelcd.eq(gicd)
                .and(qInvestmentRestriction.yyyy.eq(JPAExpressions.select(qInvestmentRestriction.yyyy.max()).from(qInvestmentRestriction)))).fetchOne();

    }

}