package com.api.yamato.value;

public interface Values {

    String IDSCDCG = "09";

    String NEW_IDSCDCG = "10";

    String PACKAGE_PATH = "com.api.yamato";

}
