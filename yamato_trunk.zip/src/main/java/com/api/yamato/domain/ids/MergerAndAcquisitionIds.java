package com.api.yamato.domain.ids;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import java.io.Serializable;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
public class MergerAndAcquisitionIds implements Serializable {

    String kiscode;

    String unite_kiscode;

}
