package com.api.yamato.domain;

import com.api.yamato.domain.ids.CorporationAddressIds;
import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.*;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_em..s_em007")
@IdClass(CorporationAddressIds.class)
public class CorporationAddress {

    @Id
    @Column(name = "upchecd")
    @GraphQLNonNull
    String kiscode;

    String rdnm_sido;

    @Transient
    String rdnm_sido2;

    @Transient
    String rdnm_sido3;

    String rdnm_sgng;

    @Transient
    String rdnm_sgng2;

    @Transient
    String rdnm_sgng3;

    String korrdnm;

    @Transient
    String korrdnm2;

    @Transient
    String korrdnm3;

    String rdnm_dtl_koraddr;

    @Transient
    String rdnm_dtl_koraddr2;

    @Transient
    String rdnm_dtl_koraddr3;

    String nolt_sido;

    @Transient
    String nolt_sido2;

    @Transient
    String nolt_sido3;

    String nolt_sgng;

    @Transient
    String nolt_sgng2;

    @Transient
    String nolt_sgng3;

    String nolt_emdg;

    @Transient
    String nolt_emdg2;

    @Transient
    String nolt_emdg3;

    String nolt_dtl_koraddr;

    @Transient
    String nolt_dtl_koraddr2;

    @Transient
    String nolt_dtl_koraddr3;

    @Id
    @Column(name = "bizlo_seq")
    Integer bizloSeq;

}
