package com.api.yamato.dao;

import com.api.yamato.domain.CorporationAddress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorporationAddressDAO extends JpaRepository<CorporationAddress, Object> {

    /**
     * 기업 주소 조회
     **/
    CorporationAddress findByKiscodeAndBizloSeq(String kiscode, int bizloSeq);

}