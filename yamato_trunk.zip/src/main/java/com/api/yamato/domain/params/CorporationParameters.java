package com.api.yamato.domain.params;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
public class CorporationParameters {

    @GraphQLNonNull
    String allsvcpdtcd;

    @GraphQLNonNull
    String kiscode;

}
