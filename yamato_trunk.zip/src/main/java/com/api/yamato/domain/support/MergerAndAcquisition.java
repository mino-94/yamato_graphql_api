package com.api.yamato.domain.support;

import com.api.yamato.domain.ids.MergerAndAcquisitionIds;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_a1..az04")
@IdClass(MergerAndAcquisitionIds.class)
public class MergerAndAcquisition {

    @Id
    @Column(name = "upchecd")
    String kiscode;

    @Id
    @Column(name = "unite_upchecd")
    String unite_kiscode;

}
