package com.api.yamato.domain.support;

import com.api.yamato.domain.ids.CorporationRehabilitationIds;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_em..s_em106")
@IdClass(CorporationRehabilitationIds.class)
public class CorporationRehabilitation {

    @Id
    @Column(name = "upchecd")
    String kiscode;

    @Id
    String lglmgmtdivcd;

    @Id
    String lglmgmt_rld_date;

}
