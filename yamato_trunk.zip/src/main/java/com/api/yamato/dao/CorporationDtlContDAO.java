package com.api.yamato.dao;

import com.api.yamato.domain.CorporationDtlCont;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CorporationDtlContDAO extends JpaRepository<CorporationDtlCont, Object> {

    /**
     * 기업 특이사항 조회
     **/
    List<CorporationDtlCont> findByKiscodeOrderBySeq(String kiscode);

}