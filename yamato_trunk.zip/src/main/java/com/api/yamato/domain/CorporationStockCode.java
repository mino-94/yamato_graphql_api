package com.api.yamato.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_ga..s_ga100")
public class CorporationStockCode {

    @Id
    @Column(name = "stockcd")
    String stkcd;

    String kor_itemnm;

    String eng_itemnm;

    @Column(name = "upchecd")
    @GraphQLNonNull
    String kiscode;

}
