package com.api.yamato.test.action;

import com.api.yamato.domain.CorporationOverview;
import com.api.yamato.domain.CorporationStockCode;
import com.api.yamato.domain.GroupOverview;
import com.api.yamato.svc.CorporationService;
import com.api.yamato.test.domain.TestCase1;
import com.api.yamato.test.domain.TestCase2;
import io.leangen.graphql.annotations.GraphQLArgument;
import io.leangen.graphql.annotations.GraphQLContext;
import io.leangen.graphql.annotations.GraphQLQuery;
import io.leangen.graphql.spqr.spring.annotations.GraphQLApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@GraphQLApi
public class CorporationTest {

    @Autowired
    private CorporationService corporationService;

    /**
     * @See Graphql은 객체 기준으로 돌아가기 떄문에, return값에 Object, Collection등 객체외 타입은 에러발생
     **/


    /**
     * 그룹 개요 조회 test
     * @param val:{gicd:"511"}
     **/
    @GraphQLQuery
    public GroupOverview groupOverview(@GraphQLArgument(name ="val") CorporationOverview corporationOverview) {
        return corporationService.getGroupOverview(corporationOverview.getGicd());
    }

    /**
     * 기업 주식코드 조회 test
     * @param data:"380725"
     **/
    @GraphQLQuery
    public CorporationStockCode corporationStockCode(@GraphQLArgument(name = "data") String kiscode) {
        return corporationService.getCorporationStockCode(kiscode);
    }

    /**
     * int test
     * @param data:12345
     * @see action/CorporationAction/corporationOverview overload
     **/
    @GraphQLQuery
    public CorporationOverview corporationOverview(@GraphQLArgument(name = "data") int testInt) {
        CorporationOverview corporationOverview = new CorporationOverview();
        corporationOverview.setBizlo_seq(testInt);
        return corporationOverview;
    }

    /**
     * no argument
     * @see parameter없는 parent호출일 경우 overload 불가능
     **/
    @GraphQLQuery
    public CorporationOverview corporationOverview2() {
        CorporationOverview corporationOverview = new CorporationOverview();
        corporationOverview.setBizlo_seq(67890);
        return corporationOverview;
    }

    /**
     * Parent - Child test case 1
     * @param kiscode:"380725"
     * @see child와 연결되어있기 때문에 corporationStockCode 호출 가능
     **/
    @GraphQLQuery
    public TestCase1 testCase1(@GraphQLArgument(name = "test1") String kiscode) {
        TestCase1 testCase1 = new TestCase1();
        testCase1.setKiscode(kiscode);
        return testCase1;
    }

    /**
     * Parent - Child test case 2
     * @param kiscode:"380725"
     * @see child와 연결되어있지 않기 때문에 corporationStockCode 호출 불가능
     **/
    @GraphQLQuery
    public TestCase2 testCase2(@GraphQLArgument(name = "test2") String kiscode) {
        TestCase2 testCase2 = new TestCase2();
        testCase2.setKiscode(kiscode);
        return testCase2;
    }

    /**
     * 기업 주식코드 조회 test case 1
     **/
    @GraphQLQuery
    public CorporationStockCode corporationStockCode(@GraphQLContext TestCase1 testCase1) {
        return corporationService.getCorporationStockCode(testCase1.getKiscode());
    }

}
