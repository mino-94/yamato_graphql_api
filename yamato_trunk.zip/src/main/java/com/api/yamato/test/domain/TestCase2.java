package com.api.yamato.test.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
public class TestCase2 {

    @GraphQLNonNull
    String kiscode;
    
}
