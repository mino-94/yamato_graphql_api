package com.api.yamato.action.support;

import com.api.yamato.domain.*;
import com.api.yamato.svc.CorporationService;
import io.leangen.graphql.annotations.GraphQLContext;
import io.leangen.graphql.annotations.GraphQLQuery;
import io.leangen.graphql.spqr.spring.annotations.GraphQLApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@GraphQLApi
public class CorporationSupport {

    @Autowired
    private CorporationService corporationService;


    /**
     * 그룹 개요 조회
     **/
    @GraphQLQuery
    public GroupOverview groupOverview(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getGroupOverview(corporationOverview.getGicd());
    }

    /**
     * 기업 은행코드 조회
     **/
    @GraphQLQuery
    public CorporationBankCode corporationBankCode(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationBankCode(corporationOverview.getMrz_bankcd());
    }

    /**
     * 기업 주식코드 조회
     **/
    @GraphQLQuery
    public CorporationStockCode corporationStockCode(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationStockCode(corporationOverview.getKiscode());
    }

    /**
     * 기업 법인등록번호 등기상태 조회
     **/
    @GraphQLQuery
    public CorporationNoStatusCode corporationNoStatusCode(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationNoStatusCode(corporationOverview.getCrpno());
    }

    /**
     * 기업 사업장 조회
     **/
    @GraphQLQuery
    public CorporationPlace corporationPlace(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationPlace(corporationOverview.getKiscode(), corporationOverview.getBizlo_seq());
    }

    /**
     * 기업 주소 조회
     **/
    @GraphQLQuery
    public CorporationAddress corporationAddress(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationAddress(corporationOverview.getKiscode(), corporationOverview.getBizlo_seq());
    }

    /**
     * 기업 휴폐업구분 조회
     **/
    @GraphQLQuery
    public CorporationHupeCode corporationHupeCode(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationHupeCode(corporationOverview.getBizno());
    }

    /**
     * 기업 특이사항 조회
     **/
    @GraphQLQuery
    public CorporationDtlCont corporationDtlCont(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationDtlCont(corporationOverview.getKiscode());
    }

    /**
     * 기업 인물코드 조회
     **/
    @GraphQLQuery
    public CorporationOwner corporationOwner(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationOwner(corporationOverview.getKiscode(), corporationOverview.getKorreprnm());
    }

    /**
     * kisreport out link 조회
     **/
    @GraphQLQuery
    public KisreportOutLink kisreportOutLink(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getKisreportOutLink(corporationOverview.getKiscode());
    }

    /**
     * 기업 로고이미지 조회
     **/
    @GraphQLQuery
    public CorporationLogoImage corporationLogoImage(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getCorporationLogoImage(corporationOverview.getBizno());
    }

    /**
     * 특수기업 조회
     **/
    @GraphQLQuery
    public SpecialCorporation specialCorporation(@GraphQLContext CorporationOverview corporationOverview) {
        return corporationService.getSpecialCorporation(corporationOverview.getKiscode());
    }

}
