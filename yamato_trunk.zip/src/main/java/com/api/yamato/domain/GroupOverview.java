package com.api.yamato.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_ea..ea01")
public class GroupOverview {

    @Id
    @GraphQLNonNull
    String kyelcd;

    @Column(name = "kyel_kor")
    String grpnm;

    @Column(name = "kyel_eng")
    String eng_grpnm;

    @Column(name = "upche_kor")
    String mainupche;

}
