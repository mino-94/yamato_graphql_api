package com.api.yamato.dao;

import com.api.yamato.domain.CorporationHupeCode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorporationHupeCodeDAO extends JpaRepository<CorporationHupeCode, Object> {

    /**
     * 기업 휴폐업구분 조회
     **/
    CorporationHupeCode findByBizno(String bizno);

}