package com.api.yamato.util;

import com.api.yamato.filter.ReadableReqWrapper;
import com.sybase.jdbc4.tds.SybTimestamp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

import javax.servlet.RequestDispatcher;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.*;

import static com.api.yamato.value.Values.PACKAGE_PATH;

@Slf4j
public class Valid {


    public static void validMethod(ReadableReqWrapper request) {
        Map data = new HashMap<>();
        String method = request.getMethod();

        if (!HttpMethod.POST.name().equals(method) && !HttpMethod.OPTIONS.name().equals(method)) {
            getErrResn(HttpStatus.METHOD_NOT_ALLOWED, data, method);
        }
        request.setAttribute(RequestDispatcher.ERROR_MESSAGE, data);
    }

    public static void validOptions(ReadableReqWrapper request, String body) {
        Map data = new HashMap<>();
        String uri = request.getRequestURI();
        String method = request.getMethod();

        if (!"/graphql".equals(uri)) {
            getErrResn(HttpStatus.NOT_FOUND, data, uri);
        } else if (HttpMethod.OPTIONS.name().equals(method) && StringUtils.isEmpty(request.getContentType()) && StringUtils.isEmpty(body)) {
            data = null;
        } else {
            data.put("chk", true);
        }
        request.setAttribute(RequestDispatcher.ERROR_MESSAGE, data);
    }

    public static void validPost(ReadableReqWrapper request, String body) {
        Map data = new HashMap<>();
        String uri = request.getRequestURI();
        String contentType = request.getContentType();
        String method = request.getMethod();

        if (!HttpMethod.POST.name().equals(method)) {
            getErrResn(HttpStatus.METHOD_NOT_ALLOWED, data, method);
        } else if (!"/graphql".equals(uri)) {
            getErrResn(HttpStatus.NOT_FOUND, data, uri);
        } else if (StringUtils.isEmpty(contentType) || !"application/graphql".equals(contentType)) {
            getErrResn(HttpStatus.UNSUPPORTED_MEDIA_TYPE, data, contentType);
        } else if (StringUtils.isEmpty(body)) {
            getErrResn(HttpStatus.NO_CONTENT, data, body);
        } else {
            data = null;
        }
        request.setAttribute(RequestDispatcher.ERROR_MESSAGE, data);
    }

    public static void getErrResn(HttpStatus status, Map result, String cause) {
        if (HttpStatus.METHOD_NOT_ALLOWED == status) {
            result.put("message", "Not Allowed Request Method, Required 'POST'");
            result.put("code", HttpStatus.METHOD_NOT_ALLOWED.value());
            result.put("cause", "Enter the Method '" + cause + "'");
        } else if (HttpStatus.NOT_FOUND == status) {
            result.put("message", "Not Found Request URI");
            result.put("code", HttpStatus.NOT_FOUND.value());
            result.put("cause", "Enter the URI '" + cause + "");
        } else if (HttpStatus.UNSUPPORTED_MEDIA_TYPE == status) {
            result.put("message", "Unsupported Content-Type, Required 'application/graphql'");
            result.put("code", HttpStatus.UNSUPPORTED_MEDIA_TYPE.value());
            result.put("cause", "Enter the Content-Type '" + cause + "'");
        } else if (HttpStatus.NO_CONTENT == status) {
            result.put("message", "Request Body is Empty");
            result.put("code", HttpStatus.NO_CONTENT.value());
            result.put("cause", "Enter the body '" + cause + "'");
        } else {
            result.put("message", "Internal Exception");
            result.put("code", 0);
            result.put("cause", cause);
        }
    }

    public static Map createTemplate(Map data) {
        List bodys = new ArrayList<>();
        Map root = new LinkedHashMap<>();
        Map body = new HashMap<>();
        body.put("message", data.get("message"));
        body.put("code", data.get("code"));
        body.put("cause", data.get("cause"));

        bodys.add(body);
        root.put("errors", bodys);

        return root;
    }

    public static boolean validRequestSchema(ReadableReqWrapper request, String body) {
        String method = request.getMethod();

        if (HttpMethod.POST.name().equals(method) && body.startsWith("query IntrospectionQuery {") && body.endsWith("}")) {
            return true;
        } else {
            return false;
        }
    }

    public static Object convertResult(Object obj) throws Exception {
        if (obj != null) {
            if (obj instanceof List) {
                List<Object> result = new ArrayList<>();

                for (Object data : (List<Object>) obj) {
                    result.add(setResult(data));
                }
                return result;
            } else {
                if (!obj.getClass().getName().startsWith(PACKAGE_PATH + ".domain")) {
                    if (obj instanceof String) {
                        return ((String) obj).trim();
                    } else if (obj == null) {
                        return "";
                    }
                    return obj;
                }
                return setResult(obj);
            }
        } else {
            return null;
        }
    }

    public static String printStackTrace(Exception e) {
        StringWriter stringWriter = new StringWriter();
        e.printStackTrace(new PrintWriter(stringWriter));

        return stringWriter.toString();
    }

    private static Object setResult(Object obj) throws Exception {
        Object val = "";

        for (Field field : obj.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            val = field.get(obj);

            if (val instanceof String) {
                val = StringUtils.isNotEmpty((String) val) ? ((String) val).trim() : "";
            } else if (val instanceof SybTimestamp) {
                val = val != null ? val.toString().trim() : "";
            } else if (val == null) {
                val = "";
            } else {
                continue;
            }
            field.set(obj, val);
        }
        return obj;
    }

}
