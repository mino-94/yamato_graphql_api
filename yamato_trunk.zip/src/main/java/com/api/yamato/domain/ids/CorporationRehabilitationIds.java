package com.api.yamato.domain.ids;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import java.io.Serializable;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
public class CorporationRehabilitationIds implements Serializable {

    String kiscode;

    String lglmgmtdivcd;

    String lglmgmt_rld_date;

}
