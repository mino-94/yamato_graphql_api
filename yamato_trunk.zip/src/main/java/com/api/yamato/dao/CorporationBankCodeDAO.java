package com.api.yamato.dao;

import com.api.yamato.domain.CorporationBankCode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorporationBankCodeDAO extends JpaRepository<CorporationBankCode, Object> {

    /**
     * 기업 은행코드 조회
     **/
    CorporationBankCode findByBankcd(String bankcd);

}