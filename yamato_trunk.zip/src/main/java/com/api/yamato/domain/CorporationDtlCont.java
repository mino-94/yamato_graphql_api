package com.api.yamato.domain;

import com.api.yamato.domain.ids.CorporationDtlContIds;
import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_em..s_em004")
@IdClass(CorporationDtlContIds.class)
public class CorporationDtlCont {

    @Id
    @Column(name = "upchecd")
    @GraphQLNonNull
    String kiscode;

    String dtlcont;

    @Id
    Integer seq;

}

