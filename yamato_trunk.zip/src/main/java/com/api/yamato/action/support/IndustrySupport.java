package com.api.yamato.action.support;

import com.api.yamato.domain.CorporationOverview;
import com.api.yamato.domain.StandardIndustryCode;
import com.api.yamato.domain.StandardIndustryName;
import com.api.yamato.svc.IndustryService;
import io.leangen.graphql.annotations.GraphQLContext;
import io.leangen.graphql.annotations.GraphQLQuery;
import io.leangen.graphql.spqr.spring.annotations.GraphQLApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@GraphQLApi
public class IndustrySupport {

    @Autowired
    private IndustryService industryService;


    /**
     * 표준 산업코드 조회
     **/
    @GraphQLQuery
    public StandardIndustryCode standardIndustryCode(@GraphQLContext CorporationOverview corporationOverview) {
        return industryService.getStandardIndustryCode(corporationOverview.getKiscode(), null);
    }

    /**
     * 표준 산업이름 조회
     **/
    @GraphQLQuery
    public StandardIndustryName standardIndustryName(@GraphQLContext StandardIndustryCode standardIndustryCode) {
        return industryService.getStandardIndustryName(standardIndustryCode.getIdscdid());
    }

}
