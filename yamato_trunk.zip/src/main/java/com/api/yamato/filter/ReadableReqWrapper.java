package com.api.yamato.filter;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.stream.Stream;

public class ReadableReqWrapper extends HttpServletRequestWrapper {

    private Charset charset;

    private byte[] data;


    ReadableReqWrapper(HttpServletRequest request) throws IOException {
        super(request);

        String charset = request.getCharacterEncoding();
        this.charset = StringUtils.isEmpty(request.getCharacterEncoding()) ? StandardCharsets.UTF_8 : Charset.forName(charset);
        data = IOUtils.toByteArray(request.getInputStream());
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
        ServletInputStream inputStream = new ServletInputStream() {
            @Override
            public boolean isFinished() {
                return byteArrayInputStream.available() == 0;
            }

            @Override
            public boolean isReady() {
                return true;
            }

            @Override
            public void setReadListener(ReadListener readListener) {
            }

            @Override
            public int read() {
                return byteArrayInputStream.read();
            }
        };
        return inputStream;
    }

    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(getInputStream(), charset));
    }

    public String getBody() throws IOException {
        StringBuilder builder = new StringBuilder();
        Stream<String> stream = getReader().lines();
        stream.forEach(str -> builder.append(str + "\n"));

        String result = builder.toString().trim();

        try {
            if (StringUtils.isNotEmpty(result)) {
                result = new JSONObject(result).get("query").toString().trim();
                data = result.getBytes();
            }
        } catch (JSONException e) {
        }
        return result;
    }

}
