package com.api.yamato.domain;

import io.leangen.graphql.annotations.GraphQLNonNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_em..vi07_s_em001")
public class CorporationOverview {

    @Id
    @Column(name = "upchecd")
    @GraphQLNonNull
    String kiscode;

    String korentrnm;

    String opt_entrnm;

    String engentrnm;

    String korreprnm;

    String engreprnm;

    String bizno;

    String crpno;

    @Transient
    String crpno_rsdrgsbdtsexvl;

    String repr_regno;

    @Transient
    String repr_rsdrgsbdtsexvl;

    String eprdtldivcd;

    String eprmdydivcd;

    String ltgmktdivcd;

    String amnisuyn;

    String etl_ipc_yn;

    String eprdatastsdivcd;

    String epr_cnu_yn;

    String cls_yndivcd;

    String empnum_bse_date;

    String empnum;

    String homepurl;

    String mainpdtpcl;

    String eng_mainpdtpcl;

    String gicd;

    String bnk_brnm;

    @Transient
    String fa_bse_date;

    String sbn_date;

    String ltg_date;

    String stacmm;

    @Transient
    String btpnm;

    @Transient
    String eng_btpnm;

    String eml;

    String scaledivcd;

    @Transient
    String scl;

    @Transient
    String eng_scl;

    String upt_dtm;

    String fadivcd;

    String etb_date;

    @Transient
    String chulja;

    @Transient
    String upt_date;

    String mrz_bankcd;

    @Column(name = "hfc_bizlo_seq")
    Integer bizlo_seq;

}
