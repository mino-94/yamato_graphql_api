package com.api.yamato.domain.support;

import com.api.yamato.domain.ids.InvestmentRestrictionIds;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Data
@NoArgsConstructor
@FieldNameConstants(level = AccessLevel.PRIVATE)
@Entity(name = "kis_ea..ea08")
@IdClass(InvestmentRestrictionIds.class)
public class InvestmentRestriction {

    @Id
    String kyelcd;

    @Id
    String yyyy;

    String chulja;

}
