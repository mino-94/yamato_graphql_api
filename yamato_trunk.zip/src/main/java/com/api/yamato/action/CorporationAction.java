package com.api.yamato.action;

import com.api.yamato.domain.CorporationOverview;
import com.api.yamato.domain.params.CorporationParameters;
import com.api.yamato.svc.CorporationService;
import io.leangen.graphql.annotations.GraphQLArgument;
import io.leangen.graphql.annotations.GraphQLQuery;
import io.leangen.graphql.spqr.spring.annotations.GraphQLApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@GraphQLApi
public class CorporationAction {

    @Autowired
    private CorporationService corporationService;


    /**
     * 기업 개요 조회
     **/
    @GraphQLQuery
    public CorporationOverview corporationOverview(@GraphQLArgument(name = "val") CorporationParameters corporationParameters) {
        return corporationService.getCorporationOverview(corporationParameters.getAllsvcpdtcd(), corporationParameters.getKiscode());
    }

}
