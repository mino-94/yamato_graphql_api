package com.api.yamato.dao;

import com.api.yamato.domain.CorporationNoStatusCode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorporationNoStatusCodeDAO extends JpaRepository<CorporationNoStatusCode, Object> {

    /**
     * 기업 법인등록번호 등기상태 조회
     **/
    CorporationNoStatusCode findByCrpno(String crpno);

}