package com.api.yamato.svc;

import com.api.yamato.dao.StandardIndustryCodeDAO;
import com.api.yamato.dao.StandardIndustryNameDAO;
import com.api.yamato.domain.StandardIndustryCode;
import com.api.yamato.domain.StandardIndustryName;
import io.leangen.graphql.annotations.GraphQLNonNull;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.api.yamato.value.Values.NEW_IDSCDCG;

@Component
public class IndustryService {

    @Autowired
    private StandardIndustryCodeDAO standardIndustryCodeDAO;

    @Autowired
    private StandardIndustryNameDAO standardIndustryNameDAO;


    /**
     * 표준 산업코드 조회
     **/
    public StandardIndustryCode getStandardIndustryCode(@GraphQLNonNull String kiscode, String idscdcg) {
        if (StringUtils.isEmpty(idscdcg) || !"10".equals(idscdcg)) {
            idscdcg = NEW_IDSCDCG;
        }
        return standardIndustryCodeDAO.findByKiscodeAndIdscdcgAndIdscdMngRnk(kiscode, idscdcg, 1);
    }

    /**
     * 표준 산업이름 조회
     **/
    public StandardIndustryName getStandardIndustryName(@GraphQLNonNull String idscdid) {
        return standardIndustryNameDAO.findByIdscdid(idscdid);
    }

}
